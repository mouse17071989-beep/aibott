# 🤖 Telegram Code Generation Bot

Легкий и крутой ИИ-бот Telegram для написания кодов, работающий на базе **OpenRouter API** с бесплатными моделями.

**Преимущества:**
- 🆓 Полностью бесплатно (используются бесплатные модели OpenRouter)
- ☁️ В облаке (работает с OpenRouter API)
- ⚡ Быстро (обработка на мощных серверах)
- 🧠 Умные модели (Trinity Large и другие современные модели)

## ✨ Возможности

- ✅ Генерация кода на любом языке программирования
- ✅ Сохранение контекста разговора (помнит предыдущие запросы)
- ✅ Обработка больших кодовых блоков
- ✅ Удобный интерфейс с командами
- ✅ Логирование и отладка
- ✅ Работает полностью локально без интернета (кроме Telegram)

## 🚀 Требования

- Python 3.8+
- Telegram Bot Token (получи от [@BotFather](https://t.me/botfather))
- OpenRouter API Key (получи бесплатно с https://openrouter.ai)

## 📦 Установка

1. **Клонируй репозиторий или создай папку проекта**

```bash
cd telegram-code-bot
```

2. **Создай виртуальное окружение**

```bash
python -m venv venv

# Windows:
venv\Scripts\activate

# Linux/Mac:
source venv/bin/activate
```

3. **Установи зависимости**

```bash
pip install -r requirements.txt
```

4. **Настрой переменные окружения**

Скопируй `.env.example` в `.env` и заполни:

```bash
cp .env.example .env
```

Отредактируй `.env`:

```env
# Telegram Bot Token от @BotFather
TELEGRAM_BOT_TOKEN=123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11

# OpenRouter Configuration
# Получи API ключ на https://openrouter.ai (бесплатно)
OPENROUTER_API_KEY=sk-or-v1-your_api_key_here
OPENROUTER_MODEL=arcee-ai/trinity-large-preview:free
OPENROUTER_API_URL=https://openrouter.ai/api/v1

# Logging
LOG_LEVEL=INFO
```

**Доступные бесплатные модели на OpenRouter:**
- `arcee-ai/trinity-large-preview:free` - Отличное качество, полностью бесплатно ⭐ (рекомендуется)
- `mistralai/mistral-7b-instruct:free` - Быстро и хорошо
- `meta-llama/llama-2-7b-chat:free` - Стабильная модель

## 🎯 Использование

### 1. Получи OpenRouter API Key

1. Перейди на https://openrouter.ai
2. Создай аккаунт (быстро и бесплатно)
3. Найди свой API ключ в Settings → API Keys
4. Скопируй ключ вида `sk-or-v1-...`

### 2. Проверь конфигурацию

```bash
python check_openrouter.py
```

Скрипт проверит:
- ✓ Формат API ключа
- ✓ Соединение с OpenRouter API
- ✓ Доступные модели
- ✓ Тестовый запрос
- ✓ Возможность использования инференса

### 3. Запусти бота

```bash
python main.py
```

**Windows:**
```bash
# Или через батник
start_bot.bat
```

### 4. Используй в Telegram

Найди своего бота и отправь:

```
/start
Напиши функцию для сортировки массива
```

### Доступные команды:

- `/start` - Начать работу и узнать мои возможности
- `/code` - Начать операцию для генерации кода
- `/help` - Справка по всем командам
- `/cancel` - Отменить текущую операцию

## 📋 Структура проекта

```
telegram-code-bot/
├── main.py                  # Основной файл бота
├── requirements.txt         # Зависимости проекта
├── .env.example            # Шаблон переменных окружения
├── .env                    # Реальные переменные (не коммитить!)
└── README.md               # Этот файл
```

## 🔧 Конфигурация

### Переменные окружения (.env):

| Переменная | Описание | Пример |
|-----------|---------|--------|
| `TELEGRAM_BOT_TOKEN` | Token от BotFather | `123456:ABC...` |
| `NEURO_API_KEY` | API ключ NeuroAPI | `sk-...` |
| `TELEGRAM_BOT_TOKEN` | Telegram Bot Token | `123456:ABC-...` |
| `OPENROUTER_API_KEY` | API ключ OpenRouter | `sk-or-v1-...` |
| `OPENROUTER_MODEL` | Модель для использования | `arcee-ai/trinity-large-preview:free` |
| `OPENROUTER_API_URL` | URL API OpenRouter | `https://openrouter.ai/api/v1` |
| `LOG_LEVEL` | Уровень логирования | `INFO`, `DEBUG`, `WARNING` |

## 💡 Как это работает

1. Пользователь отправляет запрос боту в Telegram
2. Бот сохраняет сообщение в истории беседы
3. Отправляет запрос на OpenRouter API с контекстом последних 10 сообщений
4. OpenRouter обрабатывает запрос выбранной моделью (Trinity Large Preview по умолчанию)
5. Бот получает ответ и отправляет его пользователю
6. История сохраняется в памяти для следующих уточнений

## ⚙️ Продвинутые настройки

В файле `main.py` можно настроить:

```python
MAX_CONTEXT_MESSAGES = 10      # Максимум сообщений в контексте
MAX_RESPONSE_LENGTH = 4000     # Максимальная длина ответа
```

Параметры запроса к API:
```python
"temperature": 0.7,            # 0.0 = детерминированно, 1.0 = творчески
"max_tokens": 2000,            # Максимальная длина ответа в токенах
```

## 🐛 Отладка

Для более подробного логирования установи в `.env`:

```env
LOG_LEVEL=DEBUG
```

Логи будут показывать:
- Все API запросы к OpenRouter
- Ошибки подключения и аутентификации
- Действия пользователей

## 📞 FAQ

**Q: Какую модель выбрать?**
A: Рекомендуем `arcee-ai/trinity-large-preview:free` - отличное качество и полностью бесплатна. Другие варианты смотри на https://openrouter.ai/models

**Q: Бот не отвечает**
A: Проверь:
1. API ключ верный в `.env`
2. Интернет соединение работает
3. Баланс на OpenRouter (если используешь платные модели)
4. Конфиг верный: `python check_openrouter.py`

**Q: Как изменить модель?**
A: Отредактируй `.env`:
```env
OPENROUTER_MODEL=mistralai/mistral-7b-instruct:free  # Или другую
```

Полный список моделей: https://openrouter.ai/models

**Q: Какие модели полностью бесплатны?**
A: На OpenRouter есть серия free моделей:
- `arcee-ai/trinity-large-preview:free` - Лучшее качество
- `mistralai/mistral-7b-instruct:free` - Быстро
- `meta-llama/llama-2-7b-chat:free` - Стабильно

**Q: Что если мой API ключ не работает?**
A: Это может быть:
1. API ключ неправильный - проверь на https://openrouter.ai
2. Ключ не скопирован полностью (обычно теряется конец)
3. Опечатка в `.env`
4. API ключ не готов к использованию (подожди несколько минут после создания)

Проверь с помощью:
```bash
python check_openrouter.py
```

**Q: Как долго хранится история?**
A: В памяти до перезагрузки бота (последние 10 сообщений). Для постоянного хранилища добавь БД (например, SQLite или PostgreSQL).

**Q: Как добавить админ функции?**
A: Отредактируй `main.py` и добавь проверку `user_id` в начало обработчиков.

**Q: Бот медленный**
A: OpenRouter может быть медленнее из-за интернета. Если критично:
- Используй более легкую модель (например, Mistral)
- Переходи на локальный Ollama (вернись к старой версии кода)
- Выбери модель поближе к твоему серверу

## 🚀 Деплой

### На простой сервер (Linux):

```bash
# Установка
git clone <repo-url>
cd telegram-code-bot
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env

# Отредактируй .env и добавь OPENROUTER_API_KEY
nano .env

# Проверь конфиг
python check_openrouter.py

# Запуск в фоне с nohup
nohup python main.py > bot.log 2>&1 &

# Или используй systemd/supervisor для автозапуска
# Пример для systemd в файле /etc/systemd/system/telegram-bot.service:
# [Unit]
# Description=Telegram Code Bot
# After=network.target
#
# [Service]
# Type=simple
# User=bot-user
# WorkingDirectory=/home/bot-user/telegram-code-bot
# ExecStart=/home/bot-user/telegram-code-bot/venv/bin/python main.py
# Restart=on-failure
# RestartSec=10
#
# [Install]
# WantedBy=multi-user.target
```

### На Heroku:

1. Добавь `Procfile`:
```
worker: python main.py
```

2. Добавь `runtime.txt`:
```
python-3.11.0
```

3. Деплой:
```bash
git push heroku main
```

## 📄 Лицензия

MIT License - используй свободно!

## 🚨 Troubleshooting

### ❌ "Cannot connect to Ollama at http://localhost:11434"

**Причина:** Ollama не запущен или не установлен.

**Решение:**
```bash
# 1. Установи Ollama с https://ollama.ai
# 2. Запусти Ollama
ollama serve

# 3. В другом терминале скачай модель
ollama pull mistral

# 4. Запусти бота
python main.py
```

### ❌ "model 'mistral' not found"

**Причина:** Модель не скачана.

**Решение:**
```bash
# Скачай модель:
ollama pull mistral

# Проверь что она установлена:
ollama list
```

### ❌ "Conflict: terminated by other getUpdates request"

**Причина:** Два инстанса бота запущены одновременно.

**Решение:**
```bash
# Windows:
taskkill /IM python.exe /F
python main.py

# Linux/Mac:
pkill -f "python main.py"
python main.py
```

### ⏱️ Бот очень медленный

**Причина:** Модель тяжелая или ПК слабый.

### ⏱️ Бот очень медленный

**Причина:** Сеть медленная или модель медленная.

**Решение:**
- Попробуй более быструю модель: `mistralai/mistral-7b-instruct:free`
- Проверь скорость интернета
- Напомни себе что это бесплатно 😊

### 🔄 Как изменить модель?

```bash
# Редактируй .env и замени модель на другую из доступных:
OPENROUTER_MODEL=mistralai/mistral-7b-instruct:free

# Перезапусти бота:
python main.py
```

Все доступные модели смотри на: https://openrouter.ai/models

## 🤝 Поддержка

Если найдешь ошибку или есть вопрос - создай Issue или напиши разработчику.

---

**Сделано с ❤️ для быстрого написания кода!**
